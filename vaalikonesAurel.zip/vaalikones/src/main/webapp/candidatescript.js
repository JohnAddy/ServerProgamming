/*
 author :
 */

function sendData() {
    //Create a new Javascript object
    var ehdokkaat = new Object();
    ehdokkaat.username = document.getElementById("Username").value;
    ehdokkaat.password = document.getElementById("Password").value;

    var json = JSON.stringify(ehdokkaat);
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {

            var returned = JSON.parse(this.responseText);

            console.log(returned);
            if (returned.ehdokasId > 0) {
                location.reload();
                return;
            }
            /*document.getElementById("inparts").innerHTML="ID="+returned.id+" Etunimi="+returned.etunimi+" Weight="+returned.weight;*/
        }

    };

    xhttp.open("POST", "./rest/candidateService/login", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    //xhttp.setRequestHeader("Accept","application/json");
    xhttp.send(json);


}

function sendAns(form) {
    //get all the ptag that has the class of ans and turn them into Array[]..html collection converts
    var list = [].slice.call(form.getElementsByClassName("ans")),
        i, len = list.length,
        data = [];
    for (i = 0; i < len; i++) {
        var json = list[i].getAttribute("data-json"),n = list[i].getAttribute("data-name"),name = 'input[name="'+ n +'"]:checked',
            val = form.querySelector(name).value;
            obj = JSON.parse(json);
       
        if(parseInt(val) === parseInt(obj.vastaus)){
        	//continue is used 
        	continue;
        }
        obj.vastaus = val;
        data.push(obj);
    }
  if(data.length > 0){
	  var json = JSON.stringify(data);
	    var xhttp = new XMLHttpRequest();

	    xhttp.onreadystatechange = function () {
	        if (this.readyState == 4 && this.status == 200) {

	            var returned = JSON.parse(this.responseText);

	            console.log(returned);
	            location.reload();
	        }

	    };

	    xhttp.open("POST", "./rest/candidateService/save", true);
	    xhttp.setRequestHeader("Content-Type", "application/json");
	    //xhttp.setRequestHeader("Accept","application/json");
	    xhttp.send(json);

  }
}
